package com.proyecto.servicios.onboarding.service.impl;

import com.proyecto.servicios.onboarding.dto.request.ClienteAltaRequest;
import com.proyecto.servicios.onboarding.dto.request.ClienteConsultaRequest;
import com.proyecto.servicios.onboarding.dto.request.DomicilioRequest;
import com.proyecto.servicios.onboarding.dto.response.ClienteAltaResponse;
import com.proyecto.servicios.onboarding.dto.response.ClienteResponse;
import com.proyecto.servicios.onboarding.dto.response.ClienteResumenResponse;
import com.proyecto.servicios.onboarding.dto.response.CuentaResponse;
import com.proyecto.servicios.onboarding.entity.Cliente;
import com.proyecto.servicios.onboarding.entity.Cuenta;
import com.proyecto.servicios.onboarding.entity.enums.EstadoCivil;
import com.proyecto.servicios.onboarding.entity.enums.EstatusCuenta;
import com.proyecto.servicios.onboarding.entity.enums.Sexo;
import com.proyecto.servicios.onboarding.exception.DuplicadoException;
import com.proyecto.servicios.onboarding.exception.ValidacionNegocioException;
import com.proyecto.servicios.onboarding.mapper.ClienteMapper;
import com.proyecto.servicios.onboarding.repository.ClienteRepository;
import com.proyecto.servicios.onboarding.repository.UsuarioRepository;
import com.proyecto.servicios.onboarding.service.NumeroCuentaGenerator;
import com.proyecto.servicios.onboarding.service.PaginacionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ClienteServiceImplTest {

    @Mock ClienteRepository clienteRepository;
    @Mock UsuarioRepository usuarioRepository;
    @Mock ClienteMapper mapper;
    @Mock NumeroCuentaGenerator cuentaGen;
    @Mock PasswordEncoder passwordEncoder;
    @Mock PaginacionFactory paginacionFactory;
    @InjectMocks ClienteServiceImpl service;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(service, "saldoInicial", new BigDecimal("0.00"));
    }

    @Test
    void registrar_feliz_creaClienteCuentaUsuario() {
        when(clienteRepository.existsByCurp(anyString())).thenReturn(false);
        when(clienteRepository.existsByRfc(anyString())).thenReturn(false);
        when(clienteRepository.existsByCorreo(anyString())).thenReturn(false);
        when(usuarioRepository.existsByCorreo(anyString())).thenReturn(false);

        Cliente c = Cliente.builder().id(100L).correo("test@demo.mx").activo(Boolean.TRUE).build();
        c.setCuentas(new ArrayList<>(List.of(Cuenta.builder().numeroCuenta("014180").estatus(EstatusCuenta.ACTIVA).build())));
        when(mapper.aEntidad(any())).thenReturn(c);
        when(cuentaGen.generar()).thenReturn("014180111111111111");
        when(passwordEncoder.encode(any())).thenReturn("$2a$10$enc");
        when(clienteRepository.save(any())).thenReturn(c);
        when(mapper.aCuentaResponse(any())).thenReturn(CuentaResponse.builder().numeroCuenta("014180111111111111").build());

        ClienteAltaResponse r = service.registrar(req());
        assertThat(r.id()).isEqualTo(100L);
        assertThat(r.correo()).isEqualTo("test@demo.mx");
    }

    @Test
    void registrar_lanzaCuandoCurpDuplicada() {
        when(clienteRepository.existsByCurp(anyString())).thenReturn(true);
        assertThatThrownBy(() -> service.registrar(req()))
                .isInstanceOf(DuplicadoException.class);
    }

    @Test
    void registrar_lanzaCuandoRfcDuplicado() {
        when(clienteRepository.existsByCurp(anyString())).thenReturn(false);
        when(clienteRepository.existsByRfc(anyString())).thenReturn(true);
        assertThatThrownBy(() -> service.registrar(req()))
                .isInstanceOf(DuplicadoException.class);
    }

    @Test
    void registrar_lanzaCuandoCorreoDuplicadoEnClientes() {
        when(clienteRepository.existsByCurp(anyString())).thenReturn(false);
        when(clienteRepository.existsByRfc(anyString())).thenReturn(false);
        when(clienteRepository.existsByCorreo(anyString())).thenReturn(true);
        assertThatThrownBy(() -> service.registrar(req()))
                .isInstanceOf(DuplicadoException.class);
    }

    @Test
    void registrar_lanzaCuandoMenorDeEdad() {
        LocalDate hace15 = LocalDate.now().minusYears(15);
        assertThatThrownBy(() -> service.registrar(reqConFecha(hace15)))
                .isInstanceOf(ValidacionNegocioException.class);
    }

    @Test
    void consultar_paginaMapeada() {
        Cliente c = Cliente.builder().id(1L).nombre("Juan").build();
        PageRequest pr = PageRequest.of(0, 10);
        when(paginacionFactory.toPageable(any())).thenReturn(pr);
        when(clienteRepository.findAll(any(Specification.class), eq(pr)))
                .thenReturn(new PageImpl<>(List.of(c)));
        when(mapper.aResumen(c)).thenReturn(ClienteResumenResponse.builder().id(1L).build());

        Page<ClienteResumenResponse> r = service.consultar(new ClienteConsultaRequest());
        assertThat(r.getContent()).hasSize(1);
    }

    // ---------- helpers ----------
    private ClienteAltaRequest req() {
        return reqConFecha(LocalDate.of(1995, 5, 10));
    }

    private ClienteAltaRequest reqConFecha(LocalDate fechaNac) {
        return new ClienteAltaRequest(
                "Pedro", null, "Testing", "Prueba",
                fechaNac,
                "TEPP950510HDFABC03", "TEPP950510AB1",
                Sexo.MASCULINO, "Mexicana", EstadoCivil.SOLTERO,
                "test@demo.mx", "5512345678", null,
                "Desarrollador", "DemoCorp",
                new BigDecimal("25000.00"),
                "Test1234!",
                new DomicilioRequest("Reforma","123",null,"Centro","Cuauhtemoc","CDMX","06000","Mexico")
        );
    }
}
